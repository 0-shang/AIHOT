import{p as e,t}from"./entry.client-6tyZgf_X.js";import{Jt as n,Wt as r}from"./shared-CvYixJGd.js";import{n as i,r as a,t as o}from"./CopyPage-IezEk0ct.js";var s=`# 隐私说明\r
\r
这是开源框架自带的模板，只写了这套软件默认会处理哪些数据。上线前请按你的实际情况改写（运营主体、联系方式、你另外接入的统计或服务），必要时请专业人士审阅。\r
\r
| 项 | 值 |\r
|---|---|\r
| 版本 | 0.1（模板） |\r
| 生效日期 | 请填写 |\r
| 运营主体 | 请填写 |\r
| 隐私事务联系 | 请填写 |\r
\r
页首说明：\r
\r
> 使用本站不需要注册或登录。我们只处理让网站正常运行、处理反馈所必需的信息，不出售个人信息。\r
\r
## 1. 浏览器本地数据\r
\r
收藏、已读记录、主题偏好和反馈草稿只保存在你当前的浏览器里，不会发送到服务器。清除浏览器数据后它们会消失；换设备不会同步。你可以在“收藏”页导出和导入这些数据。\r
\r
## 2. 反馈\r
\r
你在反馈页提交的内容、选填的邮箱、提交时所在页面的地址，以及你选择附上的截图，会保存在服务器上，用于处理你的反馈。为防止滥用，服务器会保存一个由网络地址和浏览器类别计算出的、无法还原的标识，用于限流和封禁滥用来源。\r
\r
## 3. 服务器与网络日志\r
\r
本软件默认不做访客统计。你的服务器、反向代理或 CDN 可能会按它们自己的配置记录访问日志（如 IP 地址、访问时间、页面地址、浏览器信息）。请在这里写明你实际使用的服务和保存期限。\r
\r
## 4. 第三方内容\r
\r
本站展示的是第三方原文的摘要与链接。点击原文链接后，你访问的是对方网站，适用对方的隐私政策。\r
\r
## 5. 联系我们\r
\r
请写明联系方式，以及查询、更正或删除反馈资料的方式。\r
`,c=t(),l=a(s);function u(){return r({title:`隐私说明`,description:`本站如何处理浏览器本地数据、反馈资料与访问日志。`,path:`/privacy`,image:`/og/pages/privacy.png`})}var d=e(function(){return(0,c.jsx)(o,{doc:l.doc,rendered:l.rendered,eyebrow:n.name,footer:(0,c.jsx)(i,{links:[{to:`/terms`,label:`使用规则`},{to:`/feedback`,label:`反馈页`}],note:`隐私说明 ${l.doc.meta.版本??``} · ${l.doc.meta.生效日期??``}`})})});export{d as default,u as meta};