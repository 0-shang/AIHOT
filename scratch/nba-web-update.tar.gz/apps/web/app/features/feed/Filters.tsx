// Feed filters: the channel and category row, and search.
import { useEffect, useRef, useState } from "react";
import { Form, Link, useNavigation, useSearchParams } from "react-router";
import { type CategoryKey, type ChannelKey } from "@aihot/contracts/taxonomy";
import { IconClose, IconSearch } from "../../components/icons";
import { PillTabs, UnderlineTabs } from "../../components/ui/Tabs";

/** Same page with some query parameters changed (paging state dropped). */
export function hrefWith(base: string, params: URLSearchParams, patch: Record<string, string | null>) {
  const sp = new URLSearchParams(params);
  for (const [k, v] of Object.entries(patch)) {
    if (v === null || v === "") sp.delete(k);
    else sp.set(k, v);
  }
  sp.delete("page");
  sp.delete("cursor");
  const s = sp.toString();
  return s ? `${base}?${s}` : base;
}

/**
 * The feed's one filter row (精选 and 全部动态 alike): 全部, 一手, then the categories. One choice at a
 * time: picking 一手 clears the category and picking a category clears 一手. Older 资讯 / X links
 * still filter; the row then shows 全部.
 */
export function CategoryTabs({
  base,
  category,
  channel = "all",
  activeKey,
  layoutId,
  size = "md",
  variant = "pill",
  className = "",
}: {
  base: string;
  category: CategoryKey | null;
  channel?: ChannelKey;
  activeKey?: string;
  layoutId: string;
  size?: "md" | "sm";
  variant?: "pill" | "underline";
  className?: string;
}) {
  const [params] = useSearchParams();
  // Tab 顺序：动态 → 热点 → 队记 → 专栏 → 流言（去掉全部，播客与视频移至一级导航）
  const items = [
    { key: "news", label: "动态", to: hrefWith(base, params, { category: "news", channel: null, reporter: null }), prefetch: "intent" as const },
    { key: "hot", label: "热点", to: "/hot", prefetch: "intent" as const },
    { key: "beat_tweets", label: "队记", to: hrefWith(base, params, { category: "beat_tweets", channel: null }), prefetch: "intent" as const },
    { key: "analysis", label: "专栏", to: hrefWith(base, params, { category: "analysis", channel: null, reporter: null }), prefetch: "intent" as const },
    { key: "trades", label: "流言", to: hrefWith(base, params, { category: "trades", channel: null, reporter: null }), prefetch: "intent" as const },
  ];
  const active = activeKey ?? (category === "beat_tweets" ? "beat_tweets" : category === "analysis" ? "analysis" : category === "trades" ? "trades" : "news");
  if (variant === "underline") {
    return <UnderlineTabs items={items} active={active} layoutId={layoutId} label="筛选" className={className} />;
  }
  return <PillTabs items={items} active={active} layoutId={layoutId} label="筛选" size={size} className={className} />;
}


function useSlashFocus(ref: React.RefObject<HTMLInputElement | null>) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "/" && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || (e.target as HTMLElement)?.isContentEditable)) {
        e.preventDefault();
        ref.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [ref]);
}

/**
 * Search field (GET /all?q=…). Desktop ("track"): at the end of the filter row as the same grey track,
 * at the height of md tabs, with a "/" hint. Phones ("bar"): full width with a separate 搜索 button.
 */
export function SearchField({ action = "/all", defaultValue = "", keep = {}, variant = "track", autoFocus = false }: { action?: string; defaultValue?: string; keep?: Record<string, string | null>; variant?: "track" | "bar" | "compact"; autoFocus?: boolean }) {
  const [value, setValue] = useState(defaultValue);
  const navigation = useNavigation();
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => setValue(defaultValue), [defaultValue]);
  useSlashFocus(inputRef);
  useEffect(() => {
    if (autoFocus) inputRef.current?.focus();
  }, [autoFocus]);
  const searching = navigation.state === "loading" && navigation.location?.pathname === action && !!new URLSearchParams(navigation.location.search).get("q");
  const hidden = Object.entries(keep).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null));

  if (variant === "compact") {
    return (
      <Form method="get" action={action} role="search" className="relative w-full">
        {hidden}
        <label className="relative block w-full">
          <span className="sr-only">搜索</span>
          <IconSearch size={14} className={`pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 transition-colors ${searching ? "text-accent" : "text-ink-4"}`} />
          <input
            ref={inputRef}
            name="q"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="搜索资讯…"
            maxLength={200}
            autoComplete="off"
            enterKeyHint="search"
            className="h-8 w-full rounded-full border border-line bg-bg-sunk/80 pl-8 pr-7 text-[12px] text-ink outline-none transition-all placeholder:text-ink-4 focus:bg-surface focus:border-accent focus:shadow-[0_0_0_2px_var(--accent-soft)] dark:border-white/10 dark:bg-bg-muted/50"
          />
          {value && (
            <button type="button" aria-label="清空" onClick={() => { setValue(""); inputRef.current?.focus(); }} className="absolute right-1.5 top-1/2 grid size-5 -translate-y-1/2 place-items-center rounded-full text-ink-4 transition-colors hover:text-ink">
              <IconClose size={12} />
            </button>
          )}
        </label>
      </Form>
    );
  }

  if (variant === "bar") {
    return (
      <Form method="get" action={action} role="search" className="relative w-full">
        {hidden}
        <label className="relative block w-full">
          <span className="sr-only">搜索标题、摘要与正文</span>
          <IconSearch size={17} className={`pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors ${searching ? "text-accent" : "text-ink-4"}`} />
          <input
            ref={inputRef}
            name="q"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="搜索火箭球员、交易流言、队记专栏…"
            maxLength={200}
            autoComplete="off"
            enterKeyHint="search"
            className="h-10.5 w-full rounded-2xl border border-line-strong/80 bg-surface pl-10 pr-9 text-[14px] text-ink shadow-2xs outline-none transition-all placeholder:text-ink-4 focus:border-accent focus:shadow-[0_0_0_3px_var(--accent-soft)] dark:border-white/10"
          />
          {value && (
            <button type="button" aria-label="清空" onClick={() => { setValue(""); inputRef.current?.focus(); }} className="absolute right-2.5 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-full text-ink-4 transition-colors hover:text-ink">
              <IconClose size={15} />
            </button>
          )}
        </label>
      </Form>
    );
  }

  return (
    <Form method="get" action={action} role="search" className="group relative w-full shrink-0 lg:w-60">
      {hidden}
      <label htmlFor="site-search" className="sr-only">
        搜索标题、摘要与正文
      </label>
      <IconSearch size={16} className={`pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${searching ? "text-accent" : "text-ink-4 group-focus-within:text-ink-3"}`} />
      <input
        ref={inputRef}
        id="site-search"
        name="q"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="搜索标题、摘要…"
        maxLength={200}
        autoComplete="off"
        className="h-[42px] w-full rounded-full bg-bg-sunk pl-10 pr-10 text-[14px] text-ink outline-none ring-1 ring-inset ring-line-soft transition-[background-color,box-shadow] placeholder:text-ink-4 hover:ring-line-strong focus:bg-surface focus:shadow-[0_0_0_3px_var(--accent-soft)] focus:ring-accent dark:bg-bg-muted/60 dark:focus:bg-surface"
      />
      {value ? (
        <button
          type="button"
          aria-label="清空"
          onClick={() => {
            setValue("");
            inputRef.current?.focus();
          }}
          className="absolute right-3 top-1/2 grid size-6 -translate-y-1/2 place-items-center rounded-full text-ink-4 transition-colors hover:bg-bg-sunk hover:text-ink"
        >
          <IconClose size={13} />
        </button>
      ) : (
        <kbd className="mono pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 rounded-mark border border-line-strong bg-surface px-1.5 text-[10.5px] leading-4 text-ink-4 lg:block">/</kbd>
      )}
    </Form>
  );
}

/** Mobile home: the search icon at the end of the category row opens search on 全部动态. */
export function SearchIconLink() {
  return (
    <Link to="/all?search=1" aria-label="搜索" className="flex size-9 shrink-0 items-center justify-center rounded-full text-ink-3 transition-colors hover:bg-bg-sunk hover:text-ink">
      <IconSearch size={19} />
    </Link>
  );
}
