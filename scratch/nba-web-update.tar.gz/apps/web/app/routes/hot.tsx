import { lazy, Suspense, useState } from "react";
import { SITE, withSubject } from "@aihot/industry/site";
import { Link, useLoaderData } from "react-router";
import type { HotEntryView, HotResponse } from "@aihot/contracts/site";
import { loadOr404 } from "../lib/api.server";
import { pageMeta } from "../lib/seo";
import { monthDayTime, shortSourceName } from "../lib/format";
import { Badge } from "../components/ui/Badge";
import { EmptyState } from "../components/ui/Page";
import { IconChevronDown, IconImage, IconInfo, IconSearch } from "../components/icons";
import { Sparkline } from "../features/hot/Sparkline";
import { Faces } from "../features/hot/Faces";
import { Delta } from "../features/hot/Delta";
import { CategoryTabs, SearchField } from "../features/feed/Filters";

const PosterSheet = lazy(() => import("../features/item/PosterSheet"));

export async function loader({ request }: { request: Request }) {
  return { hot: await loadOr404<HotResponse>("/api/site/hot", { signal: request.signal }) };
}

export function meta() {
  return pageMeta({
    title: withSubject("热点榜"),
    description: "过去 48 小时休斯敦火箭全网讨论最多的热点事件：热度指数、趋势与公开信源。",
    path: "/hot",
    image: "/og/pages/hot.png",
  });
}

export function headers() {
  return { "Cache-Control": "public, max-age=0, s-maxage=120, stale-while-revalidate=60" };
}

const BADGES: Record<HotEntryView["badges"][number], { label: string; tone: "hot" | "accent" | "amber"; hint: string }> = {
  surge: { label: "爆", tone: "hot", hint: "讨论快速增加" },
  new: { label: "新", tone: "accent", hint: "首报 6 小时内" },
  rising: { label: "发酵中", tone: "amber", hint: "讨论仍在增加" },
};

const RANK_COLOR = ["text-rank-1", "text-rank-2", "text-rank-3"];
const rankColor = (rank: number) => RANK_COLOR[rank - 1] ?? "text-rank-rest";
const pad = (rank: number) => String(rank).padStart(2, "0");

/** "TechCrunch、The Verge 等 4 个来源 · 7 位参与者". */
function Voices({ e }: { e: HotEntryView }) {
  const names = e.sourceNames.slice(0, 2).map(shortSourceName);
  return (
    <span className="min-w-0 text-[12.5px] leading-snug text-ink-4">
      {/* Lines break between the phrases, never inside one. */}
      <span className="whitespace-nowrap">
        {names.length > 0 && <span className="text-ink-3">{names.join("、")}</span>}
        {e.sourceCount > names.length ? ` 等 ${e.sourceCount} 个来源` : names.length ? " 报道" : `${e.sourceCount} 个来源`}
      </span>
      <span className="mx-1.5 text-line-strong">·</span>
      <span className="whitespace-nowrap">
        <span className="num">{e.participantCount}</span> 位参与者
      </span>
    </span>
  );
}

function Badges({ e }: { e: HotEntryView }) {
  return e.badges.map((b) => (
    <Badge key={b} tone={BADGES[b].tone} title={BADGES[b].hint}>
      {BADGES[b].label}
    </Badge>
  ));
}

/** The whole card opens the event; the title carries the link and stretches over the card. */
function StoryLink({ e, className }: { e: HotEntryView; className: string }) {
  return (
    <Link to={`/story/${e.story.publicId}`} prefetch="intent" className={`transition-colors after:absolute after:inset-0 after:content-[''] ${className}`}>
      {e.story.title}
    </Link>
  );
}

/** No. 1: the event people are talking about most, with its digest, latest turn and day of heat. */
function Lead({ e }: { e: HotEntryView }) {
  return (
    <article className="card card-hover group relative flex flex-col overflow-hidden p-5 sm:p-6">
      <div className="flex items-center gap-2.5">
        <span className={`mono text-[12px] font-bold tracking-[0.16em] ${rankColor(e.rank)}`}>NO.{pad(e.rank)}</span>
        <Badges e={e} />
        <Delta trend={e.trend} pct={e.trendPct} className="ml-auto" />
      </div>
      <div className="mt-4 min-w-0">
        <h2 className="text-[21px] font-bold leading-[1.4] tracking-[-0.01em] text-ink sm:text-[23px] lg:text-[25px] lg:leading-[1.38]">
          <StoryLink e={e} className="group-hover:text-accent" />
        </h2>
        {e.summary && <p className="mt-3 text-[14px] leading-[1.75] text-ink-3">{e.summary}</p>}
      </div>
      {/* Side by side while the card is wide enough */}
      <div className="mt-auto flex flex-wrap items-end gap-x-6 gap-y-4 pt-5">
        <div className="min-w-0 flex-[1_1_18rem] space-y-2.5">
          {e.latest && (
            <p className="line-clamp-2 text-[13px] leading-[1.7] text-ink-2">
              <span className="mr-2 text-[12px] font-semibold text-accent">最新进展</span>
              {e.latest}
            </p>
          )}
          <div className="flex items-center gap-3">
            <Faces participants={e.participants} total={e.participantCount} size={24} />
            <Voices e={e} />
          </div>
        </div>
        <div className="flex w-full shrink-0 items-end justify-between gap-5 sm:ml-auto sm:w-auto sm:justify-end">
          <Sparkline values={e.spark} area className="h-10 w-[140px] text-accent" />
          <div className="text-right">
            <div className="mono text-[34px] font-semibold leading-none tracking-[-0.03em] text-ink">{Math.round(e.heat)}</div>
            <div className="mt-1 text-[11.5px] text-ink-4">热度指数</div>
          </div>
        </div>
      </div>
    </article>
  );
}

/** No. 2 and 3: the same card, smaller, without the picture. */
function Runner({ e }: { e: HotEntryView }) {
  return (
    <article className="card card-hover group relative flex flex-col px-5 py-4">
      <div className="flex items-center gap-2.5">
        <span className={`mono text-[12px] font-bold tracking-[0.16em] ${rankColor(e.rank)}`}>NO.{pad(e.rank)}</span>
        <Badges e={e} />
        <Delta trend={e.trend} pct={e.trendPct} className="ml-auto" />
      </div>
      <h2 className="mt-2.5 line-clamp-2 text-[16px] font-[650] leading-[1.5] text-ink">
        <StoryLink e={e} className="group-hover:text-accent" />
      </h2>
      {e.summary && <p className="mt-1.5 line-clamp-2 text-[13px] leading-[1.7] text-ink-3 lg:line-clamp-1">{e.summary}</p>}
      <div className="mt-auto flex items-end justify-between gap-4 pt-3">
        <div className="flex min-w-0 flex-col gap-1.5">
          <Faces participants={e.participants} total={e.participantCount} size={20} />
          <span className="text-[12px] text-ink-4">
            <span className="whitespace-nowrap"><span className="num">{e.sourceCount}</span> 个来源</span> ·{" "}
            <span className="whitespace-nowrap"><span className="num">{e.participantCount}</span> 位参与者</span>
          </span>
        </div>
        <div className="flex items-end gap-3">
          <Sparkline values={e.spark} className="h-7 w-[92px] text-accent" />
          <span className="mono text-[24px] font-semibold leading-none tracking-[-0.02em] text-ink">{Math.round(e.heat)}</span>
        </div>
      </div>
    </article>
  );
}

/** No. 4–10: a row each, with a line of the digest, faces, the day of heat and the index. */
function Row({ e }: { e: HotEntryView }) {
  return (
    <li className="group relative grid grid-cols-[30px_minmax(0,1fr)] items-start gap-x-3 px-4 py-3 transition-colors hover:bg-bg-sunk/70 sm:px-5 lg:grid-cols-[44px_minmax(0,1fr)_auto_104px_76px] lg:items-center lg:gap-x-6 lg:px-6 lg:py-3.5 dark:hover:bg-bg-muted/40">
      <span className={`mono text-[16px] font-semibold leading-[24px] lg:text-[17px] ${rankColor(e.rank)}`} aria-label={`热度排名第 ${e.rank} 位`}>
        {pad(e.rank)}
      </span>
      <div className="min-w-0">
        <h3 className="text-[15px] font-[650] leading-[1.55] text-ink">
          <StoryLink e={e} className="group-hover:text-accent" />
          {e.badges.length > 0 && (
            <span className="ml-2 inline-flex translate-y-[-2px] gap-1 align-middle">
              <Badges e={e} />
            </span>
          )}
        </h3>
        {e.summary && <p className="mt-0.5 line-clamp-2 text-[13px] leading-[1.65] text-ink-4 lg:line-clamp-1">{e.summary}</p>}
        <div className="mt-2 flex items-center gap-2.5 lg:hidden">
          <Faces participants={e.participants} total={e.participantCount} size={20} />
          <span className="text-[12px] text-ink-4">
            <span className="num">{e.sourceCount}</span> 个来源
          </span>
          <span className="ml-auto flex items-center gap-2">
            <span className="mono text-[17px] font-semibold leading-none text-ink">{Math.round(e.heat)}</span>
            <Delta trend={e.trend} pct={e.trendPct} />
          </span>
        </div>
      </div>
      <div className="hidden items-center gap-2.5 lg:flex">
        <Faces participants={e.participants} total={e.participantCount} size={20} />
      </div>
      <Sparkline values={e.spark} className="hidden h-7 w-[104px] text-accent lg:block" />
      <div className="hidden flex-col items-end gap-1 lg:flex">
        <span className="mono text-[20px] font-semibold leading-none tracking-[-0.02em] text-ink">{Math.round(e.heat)}</span>
        <Delta trend={e.trend} pct={e.trendPct} />
      </div>
    </li>
  );
}

export default function HotPage() {
  const { hot } = useLoaderData<typeof loader>();
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [posterOpen, setPosterOpen] = useState(false);
  const [lead, ...rest] = hot.entries;
  const runners = rest.slice(0, 2);
  const others = rest.slice(2);
  return (
    <div className="pb-10">
      {/* Desktop Header */}
      <div className="hidden lg:block">
        <div className="flex items-baseline justify-between">
          <h1 className="text-[26px] font-black tracking-tight text-ink lg:text-3xl">火箭队资讯</h1>
        </div>
        <div className="mb-4 mt-4 flex flex-wrap items-center justify-between gap-3">
          <CategoryTabs base="/all" category={null} activeKey="hot" layoutId="hot-cat-desk" className="min-w-0" />
          <SearchField variant="track" keep={{ category: null }} />
        </div>
      </div>

      {/* Phones: Option 1 Editorial Sticky Header */}
      <div className="lg:hidden sticky top-0 z-30 -mx-4 px-4 pt-3 pb-2.5 bg-surface/95 backdrop-blur-md border-b border-line-soft shadow-xs transition-colors">
        {/* Row 1: Brand Wordmark + Search Icon Button */}
        <div className="flex items-center justify-between h-8">
          <Link to="/" className="flex items-baseline gap-1 shrink-0 text-ink no-underline">
            <span className="font-black text-[18px] tracking-tight">
              CLUTCH<span className="text-[#CE1141]">WIRE</span>
            </span>
          </Link>
          <button
            type="button"
            onClick={() => setMobileSearchOpen((prev) => !prev)}
            aria-label="搜索"
            className={`flex size-8 items-center justify-center rounded-full transition-all ${
              mobileSearchOpen
                ? "bg-[#CE1141] text-white shadow-xs"
                : "text-ink-3 hover:text-ink hover:bg-bg-sunk active:scale-95"
            }`}
          >
            <IconSearch size={17} />
          </button>
        </div>

        {/* Expandable Search Input */}
        {mobileSearchOpen && (
          <div className="pt-2 pb-1 anim-fade-in">
            <SearchField variant="bar" keep={{ category: null }} autoFocus />
          </div>
        )}

        {/* Row 2: Underline Category Tabs */}
        <div className="mt-2">
          <CategoryTabs base="/all" category={null} activeKey="hot" layoutId="hot-cat-mobile" variant="underline" className="w-full" />
        </div>
      </div>
      <header className="flex flex-wrap items-end justify-between gap-x-6 gap-y-3 pb-5 pt-3">
        <div>
          <div className="flex items-center gap-2 text-[12px] font-semibold tracking-[0.08em] text-hot">
            <span className="relative flex size-2" aria-hidden="true">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-hot opacity-30" />
              <span className="relative inline-flex size-2 rounded-full bg-hot" />
            </span>
            实时热度
          </div>
          <h1 className="mt-1.5 text-[24px] font-bold leading-[1.3] tracking-[-0.01em] text-ink lg:text-[26px]">{withSubject("热点榜")}</h1>
          <p className="mt-1.5 text-[13.5px] text-ink-3">过去 {hot.windowHours} 小时，休斯敦火箭全网讨论最多的 {hot.entries.length || 10} 件事</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setPosterOpen(true)}
            className="inline-flex h-8 items-center gap-1.5 rounded-full border border-line-strong bg-surface px-3 text-[12.5px] font-medium text-ink-2 shadow-xs transition-all hover:border-[#CE1141] hover:text-[#CE1141] active:scale-95"
            title="生成热点榜长图海报，适合分享到虎扑、微信群与朋友圈"
          >
            <IconImage size={14} className="text-[#CE1141]" />
            <span>生成热点海报</span>
          </button>
          {hot.computedAt && (
            <p className="text-[12px] text-ink-4">
              <span className="num">{monthDayTime(hot.computedAt)}</span> 更新 · 按讨论热度排序
            </p>
          )}
        </div>
      </header>

      {!lead ? (
        <div className="card rounded-sheet">
          <EmptyState title="暂时没有热点">还没有足够多来源共同讨论的事件。</EmptyState>
        </div>
      ) : (
        <>
          <section aria-label="热度前三" className="grid gap-3 lg:grid-cols-12 lg:gap-4">
            <div className="grid lg:col-span-7 lg:row-span-2 xl:col-span-8">
              <Lead e={lead} />
            </div>
            {runners.map((e) => (
              <div key={e.story.publicId} className="grid lg:col-span-5 xl:col-span-4">
                <Runner e={e} />
              </div>
            ))}
          </section>

          {others.length > 0 && (
            <section aria-label="其余热点" className="mt-6 lg:mt-7">
              <div className="mb-3 flex items-baseline justify-between px-1">
                <h2 className="text-[15px] font-semibold text-ink">
                  继续看 <span className="num font-normal text-ink-4">No.{pad(others[0]!.rank)}–{pad(others[others.length - 1]!.rank)}</span>
                </h2>
                <span className="hidden text-[12px] text-ink-4 lg:block">参与者 · 24 小时走势 · 热度指数</span>
              </div>
              <ol className="card divide-y divide-line-soft overflow-hidden">
                {others.map((e) => (
                  <Row key={e.story.publicId} e={e} />
                ))}
              </ol>
            </section>
          )}
        </>
      )}

      <details className="disclosure group/method mt-8 text-[12px] text-ink-4">
        <summary className="flex items-center gap-1.5 py-1 transition-colors hover:text-ink-2">
          <IconInfo size={15} />
          热度是怎么算的？
          <span className="ml-auto inline-flex items-center gap-0.5">
            <span className="group-open/method:hidden">了解榜单</span>
            <span className="hidden group-open/method:inline">收起</span>
            <IconChevronDown size={13} className="transition-transform duration-200 group-open/method:rotate-180" />
          </span>
        </summary>
        <div className="max-w-[760px] space-y-2 pb-2 pl-[21px] pt-2 leading-[1.75] text-ink-3">
          <p>热度来自参与同一事件的独立账号与机构，重复采集只算一次，并按 24 小时半衰期衰减。它衡量讨论活跃程度，不是报道质量评分。</p>
          <p>榜单统计过去 48 小时。趋势只比较持续覆盖的同一组信源；它反映我们的监测范围，不代表全网人数。缺少可比历史时，不展示趋势线。</p>
          <p>
            信源名单只展示可公开阅读的报道来源；讨论参与者还包括只计入热度的账号与机构。同一机构的多个渠道可能合并计数，因此参与者不一定多于信源数。点击事件可查看各方报道与观点。
          </p>
          <dl className="flex flex-wrap gap-x-5 gap-y-1.5 pt-1">
            {Object.values(BADGES).map((b) => (
              <div key={b.label} className="flex items-center gap-1.5">
                <dt>
                  <Badge tone={b.tone}>{b.label}</Badge>
                </dt>
                <dd>{b.hint}</dd>
              </div>
            ))}
          </dl>
        </div>
      </details>
      {posterOpen && (
        <Suspense fallback={null}>
          <PosterSheet
            id="hot"
            title="休斯敦火箭 · 全网热点榜"
            open={posterOpen}
            onClose={() => setPosterOpen(false)}
            aspect="9/16"
          />
        </Suspense>
      )}
    </div>
  );
}
